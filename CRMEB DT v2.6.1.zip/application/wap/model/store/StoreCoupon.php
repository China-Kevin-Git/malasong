<?php
/**
 *
 * @author: xaboy<365615158@qq.com>
 * @day: 2018/01/22
 */

namespace app\wap\model\store;


use basic\ModelBasic;
use traits\ModelTrait;

class StoreCoupon extends ModelBasic
{
    use ModelTrait;
}
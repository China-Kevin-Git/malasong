<?php

/**
 * Created by PhpStorm.
 * User: xurongyao <763569752@qq.com>
 * Date: 2019/4/8 5:48 PM
 */
namespace app\core\logic;

class Template
{

}
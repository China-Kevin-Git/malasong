<?php
/**
 * Created by CRMEB.
 * User: 136327134@qq.com
 * Date: 2019/4/12 11:23
 */

namespace app\core\implement;

/*
 * 监听行为默认运行方法接口
 *
 * */

interface BehaviorIntterface
{


    public function run();
}
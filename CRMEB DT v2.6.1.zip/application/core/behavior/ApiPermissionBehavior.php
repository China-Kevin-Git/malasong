<?php
/**
 * Created by CRMEB.
 * User: 136327134@qq.com
 * Date: 2019/4/12 11:21
 */

namespace app\core\behavior;

use app\core\implement\BehaviorIntterface;

/*
 * Api权限处理
 * class ApiPermissionBehavior
 * */
class ApiPermissionBehavior implements BehaviorIntterface
{
    public function run()
    {

    }

}
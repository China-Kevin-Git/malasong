<?php
/**
 * Created by CRMEB.
 * User: 136327134@qq.com
 * Date: 2019/4/12 11:22
 */

namespace app\core\behavior;

use app\core\implement\BehaviorIntterface;

class BuildResponseBehavior implements BehaviorIntterface
{
    public function run()
    {

    }

}
<?php
/**
 * Created by CRMEB.
 * User: 136327134@qq.com
 * Date: 2019/4/12 17:00
 */

namespace app\core\model;

/*
 * Api接口列表
 * class ApiMenus
 * */
class ApiMenus
{


    /*
     * 接口列表配置
     *
     * */
    protected $hash=[

    ];

    /*
     * 获取
     * */
    public static function getHash($name)
    {

    }

}
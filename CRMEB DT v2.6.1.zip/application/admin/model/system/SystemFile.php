<?php
/**
 *
 * @author: xaboy<365615158@qq.com>
 * @day: 2017/11/13
 */

namespace app\admin\model\system;

use traits\ModelTrait;
use basic\ModelBasic;

/**
 * 附件管理model
 * Class SystemAttachment
 * @package app\admin\model\system
 */
class SystemFile extends ModelBasic
{
    use ModelTrait;


}
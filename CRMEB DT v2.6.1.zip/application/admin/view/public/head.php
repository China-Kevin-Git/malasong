<meta charset="UTF-8">
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
<link rel="stylesheet" href="{__ADMIN_PATH}css/main.css">
<link rel="stylesheet" href="{__STATIC_PATH}css/animate.css">
{include file="public/style"}
<script>
    $eb = parent._mpApi;
//    if(!$eb) top.location.reload();
</script>
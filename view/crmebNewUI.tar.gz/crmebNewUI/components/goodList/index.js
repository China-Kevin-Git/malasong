// components/goodList/index.js
Component({
  properties: {
    status: {
      type: String,
      value: 0,
    },
    bastList: {
      type: Object,
      value: [],
    }
  },
  data: {
    
  }
})
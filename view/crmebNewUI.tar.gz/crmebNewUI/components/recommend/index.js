var app = getApp();
Component({
  properties: {
    host_product:{
      type: Object,
      value:[],
    }
  },
  data: {
  },
  attached: function () {
  },
  methods: {
  }
})